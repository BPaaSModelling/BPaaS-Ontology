![ArchiMEO](https://raw.github.com/ikm-group/ArchiMEO/gh-pages/ArchiMEO-logo/ArchiMEO_logo_text.png "ArchiMEO")
========
Welcome to the ArchiMEO Ontology.

![Alternativtext](http://i.creativecommons.org/l/by-sa/3.0/88x31.png "Bildtitel hier") ArchiMEO by [University of Applied Sciences and Arts Northwestern Switzerland FHNW](http://www.fhnw.ch "University of Applied Sciences and Arts Northwestern Switzerland FHNW") is licensed under a [Creative Commons Attribution-ShareAlike 3.0 Unported License](http://creativecommons.org/licenses/by-sa/3.0/ "Creative Commons Attribution-ShareAlike 3.0 Unported License").