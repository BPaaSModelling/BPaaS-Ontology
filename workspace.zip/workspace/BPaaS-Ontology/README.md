# BPaaS-Ontology
Purpose
--------